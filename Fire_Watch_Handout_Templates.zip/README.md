# La Habra Heights Fire Watch preparedness handouts

Edit the text in `one-page.html` or `two-page.html` and open the file in a browser. Print at **US Letter**, **100% scale**, with **background graphics enabled**. Print the two-page file **double-sided, flip on long edge**. The page labeled FRONT is page 1.

The front page's section strip is on the right edge. The back page's strip is on the left edge, so both appear on the outside of a turned page. Leave the 0.75-inch binding margin clear. Test on your actual printer and binder before printing a run: printers have different nonprintable margins and duplex alignment.

## Editing and collaboration

Use GitHub for the source files. Make one HTML file per handout in a `pages/` folder, and propose edits through pull requests. Review content accuracy separately from the final printed proof. Keep `style.css` shared so a design change applies to the full collection. When the collection grows, move the page text to Markdown and add a build step; starting with plain HTML keeps this first version easy to preview and print without installing software.

Suggested filename: `02-03-report-wildfire.html` (section number, page number, subject). Assign a stable document code such as `COM-03` and a review date to every handout. Publish PDFs from reviewed source; keep the editable HTML in GitHub.

Replace the sample text and the `DRAFT / SAMPLE` marks before distribution. Have subject matter reviewers check instructions, phone numbers, agency language, and safety advice. No official seal or endorsement is implied by these draft templates.
